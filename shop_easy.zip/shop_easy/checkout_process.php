<?php include "includes/db.php";?>
<?php ob_start(); ?>
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="styles/orders.css">
  <link rel="stylesheet" href="styles/checkout.css">
</head>

<?php include "includes/checkout-header.php"; ?>

<body>
<div class="shipping-details">

<?php

if(isset($_POST['payment-button'])){

  $fullname = $_POST['full_name'];
  $address = $_POST['address'];
  $city = $_POST['city'];
  $state = $_POST['state'];
  $zip = $_POST['zip_code'];
  $phone = $_POST['phone'];

//   $country = $_POST['country'];
//   $payment_method = $_POST['payment_method'];

  $order_total = $_SESSION['order_total'];

  $query = "INSERT INTO orders (user_id, transaction_id, total_amount, shipping_address, order_status) VALUES ({$_SESSION['user_id']}, 'xyu21ui31nwe', '$order_total', '$address', 'Pending')";
  $result = $connection->query($query);

  $cart_query = "DELETE FROM cart WHERE user_id = {$_SESSION['user_id']}";
  $cart_result = $connection->query($cart_query);

  echo "<h4 style='color: green;'>Congratulations! Your Order Is Now Under Review👍 <a href='orders.php'>View Your Order(s)</a></h4>";

//   if($result) {
//     // Get the order ID
//     $order_id = $connection->insert_id;

//     // Now insert the cart items into the order_items tablex
//     foreach ($_SESSION['cart'] as $product_id => $quantity) {
//       // Get product price
//       $product_query = "SELECT * FROM products WHERE product_id = $product_id";
//       $product_result = $connection->query($product_query);
//       $product = mysqli_fetch_assoc($product_result);
//       $product_price = $product['product_price'];

//       // Insert each cart item into order_items table
//       $insert_order_item = "INSERT INTO order_items (order_id, product_id, quantity, price)
//                             VALUES ('$order_id', '$product_id', '$quantity', '$product_price')";
//       $connection->query($insert_order_item);
//     }

//     // Clear cart session after successful checkout
//     unset($_SESSION['cart']);
//     $_SESSION['cart_num'] = 0;
    
//     // Redirect to order confirmation page
//     header("Location: order_confirmation.php?order_id=$order_id");
//     exit();
//   } else {
//     die("Error: Could not place the order.");
//   }
}
?>


    <h2>Shipping Information</h2>

    
    <form action="" method="POST">
        <div class="form-group">
            <label for="full_name">Full Name:</label>
            <input type="text" id="full_name" name="full_name" required>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" id="city" name="city" required>
        </div>
        <div class="form-group">
            <label for="state">State:</label>
            <input type="text" id="state" name="state" required>
        </div>
        <div class="form-group">
            <label for="zip_code">Zip Code:</label>
            <input type="text" id="zip_code" name="zip_code" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>
        </div>
        <input type="submit" name='payment-button' class="payment-button" value='Proceed to Payment'>
    </form>
</div>

</body>
</html>

