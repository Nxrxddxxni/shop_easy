<?php
// session_start();
include "includes/checkout-header.php";
?>
<div class="main">
      <div class="page-title">Review your order</div>

      <div class="checkout-grid">
        <div class="cart-item-container">
          <?php

$user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : ''; 
$items_cost = 0;

// If user is logged in, fetch their cart from the database
if ($user_id) {
    $query = "SELECT * FROM cart WHERE user_id = ?";
    $stmt = $connection->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $_SESSION['cart_num'] = 0;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $quantity = $row['quantity'];
            $pro_id = intval($row['product_id']);
            $cart_id = intval($row['cart_id']);

            $_SESSION['cart_num'] += $quantity; 
            // Fetch product details
            $pro_query = "SELECT * FROM products WHERE product_id = ?";
            $stmt2 = $connection->prepare($pro_query);
            $stmt2->bind_param("i", $pro_id);
            $stmt2->execute();
            $pro_result = $stmt2->get_result();

            if ($product = $pro_result->fetch_assoc()) {
                $items_cost += ($product['product_price'] * $quantity);
                $_SESSION['order_total'] = $items_cost;
                ?>

                <div class='cart-pro'>
                    <div class="cart-item-details-grid">
                        <img class="product-image" src="images/<?php echo $product['product_image']; ?>">
                        <div class="cart-item-details">
                            <div class="product-name"><?php echo $product['product_description']; ?></div>
                            <div class="product-price">&#8358;<?php echo number_format($product['product_price'], 2); ?></div>
                            <div class="product-quantity">
                                <span>Quantity: <span class="quantity-label"><?php echo $quantity; ?></span></span>
                                <span class="update-quantity-link link-primary">Update</span>
                                <a href="checkout.php?delete=<?php echo $cart_id; ?>"><span class="delete-quantity-link link-primary">Delete</span></a>
                            </div>
                        </div>
                    </div>
                </div>

                <?php 
            }
        }
    } else {
        echo "<h1>No Items In Your Cart</h1>";
    }
} else {
    // Guest cart (session-based)
    if (!empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product_id => $quantity) {
            $product_id = intval($product_id);

            $sql = "SELECT * FROM products WHERE product_id = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $pro_result = $stmt->get_result();

            if ($row = $pro_result->fetch_assoc()) {
                $product_price = $row['product_price'] * $quantity;
                $items_cost += $product_price;
                ?>
                <div class='cart-pro'>
                    <a href="checkout.php?delete=<?php echo $product_id; ?>" class="cancel-button">X</a>
                    <div class="cart-item-details-grid">
                        <img class="product-image" src="images/<?php echo $row['product_image']; ?>">
                        <div class="cart-item-details">
                            <div class="product-name"><?php echo $row['product_description']; ?></div>
                            <div class="product-price">&#8358;<?php echo number_format($row['product_price'], 2); ?></div>
                            <div class="product-quantity">
                                <span>Quantity: <span class="quantity-label"><?php echo $quantity; ?></span></span>
                                <span class="update-quantity-link link-primary">Update</span>
                                <a href="checkout.php?delete=<?php echo $product_id; ?>"><span class="delete-quantity-link link-primary">Delete</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
            }
        }
    } else {
        echo "<h1>No Items In Your Cart</h1>";
    }
}

include "includes/cart-summary.php";
?>
