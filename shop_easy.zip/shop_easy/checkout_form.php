<form class="row g-3 needs-validation" novalidate>
  <div class="col-md-4">
    <label for="validationCustom01" class="form-label">First name</label>
    <input type="text" class="form-control" id="validationCustom01" value="Mark" required>
    <div class="valid-feedback">
      Looks good!
    </div>
  </div>
  <div class="col-md-4">
    <label for="validationCustom02" class="form-label">Last name</label>
    <input type="text" class="form-control" id="validationCustom02" value="Otto" required>
    <div class="valid-feedback">
      Looks good!
    </div>
  </div>
  <div class="col-md-4">
    <label for="validationCustomUsername" class="form-label">Username</label>
    <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend">@</span>
      <input type="text" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
      <div class="invalid-feedback">
        Please choose a username.
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <label for="validationCustom03" class="form-label">City</label>
    <input type="text" class="form-control" id="validationCustom03" required>
    <div class="invalid-feedback">
      Please provide a valid city.
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationCustom04" class="form-label">State</label>
    <select class="form-select" id="validationCustom04" required>
      <option selected disabled value="">Choose...</option>
      <option>...</option>
    </select>
    <div class="invalid-feedback">
      Please select a valid state.
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationCustom05" class="form-label">Zip</label>
    <input type="text" class="form-control" id="validationCustom05" required>
    <div class="invalid-feedback">
      Please provide a valid zip.
    </div>
  </div>
  <div class="col-12">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
      <label class="form-check-label" for="invalidCheck">
        Agree to terms and conditions
      </label>
      <div class="invalid-feedback">
        You must agree before submitting.
      </div>
    </div>
  </div>
  <div class="col-12">
    <button class="btn btn-primary" type="submit">Submit form</button>
  </div>
</form>


<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>


<input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
<label class="btn btn-primary" for="btn-check">Single toggle</label>



<input type="checkbox" class="btn-check" id="btn-check-2" checked autocomplete="off">
<label class="btn btn-primary" for="btn-check-2">Checked</label>



<div class="checkout-form-container">
  <h2>Checkout</h2>
  <form action="process_checkout.php" method="POST">
    
    <!-- User details (if logged in, these should be pre-filled) -->
    <div class="form-group">
      <label for="fullname">Full Name</label>
      <input type="text" id="fullname" name="fullname" value="<?php echo isset($user_info['fullname']) ? $user_info['fullname'] : ''; ?>" required>
    </div>

    <div class="form-group">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" value="<?php echo isset($user_info['email']) ? $user_info['email'] : ''; ?>" required>
    </div>

    <div class="form-group">
      <label for="phone">Phone Number</label>
      <input type="text" id="phone" name="phone" value="<?php echo isset($user_info['phone']) ? $user_info['phone'] : ''; ?>" required>
    </div>

    <div class="form-group">
      <label for="address">Shipping Address</label>
      <textarea id="address" name="address" required><?php echo isset($user_info['address']) ? $user_info['address'] : ''; ?></textarea>
    </div>

    <div class="form-group">
      <label for="city">City</label>
      <input type="text" id="city" name="city" required>
    </div>

    <div class="form-group">
      <label for="zip">Zip Code</label>
      <input type="text" id="zip" name="zip" required>
    </div>

    <div class="form-group">
      <label for="country">Country</label>
      <input type="text" id="country" name="country" required>
    </div>

    <!-- Payment Method Selection -->
    <div class="form-group">
      <label for="payment_method">Payment Method</label>
      <select id="payment_method" name="payment_method" required>
        <option value="credit_card">Credit Card</option>
        <option value="paypal">PayPal</option>
        <option value="bank_transfer">Bank Transfer</option>
      </select>
    </div>

    <button type="submit" name="submit_checkout">Place Order</button>
  </form>
</div>


<?php
session_start();
include "includes/db.php";

// Check if the form was submitted
if(isset($_POST['submit_checkout'])){
  // Validate the form inputs
  $fullname = $_POST['fullname'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $address = $_POST['address'];
  $city = $_POST['city'];
  $zip = $_POST['zip'];
  $country = $_POST['country'];
  $payment_method = $_POST['payment_method'];

  // Basic validation (check if any required field is empty)
  if(empty($fullname) || empty($email) || empty($phone) || empty($address) || empty($city) || empty($zip) || empty($country)) {
    die("Please fill in all required fields.");
  }

  // Calculate the total order cost
  $order_total = $_SESSION['order_total'];  // This should already be calculated from cart items

  // Insert the order details into the database
  $query = "INSERT INTO orders (user_id, fullname, email, phone, address, city, zip, country, payment_method, total_amount, order_status)
            VALUES ('{$_SESSION['user_id']}', '$fullname', '$email', '$phone', '$address', '$city', '$zip', '$country', '$payment_method', '$order_total', 'Pending')";
  $result = $connection->query($query);

  if($result) {
    // Get the order ID
    $order_id = $connection->insert_id;

    // Now insert the cart items into the order_items tablex
    foreach ($_SESSION['cart'] as $product_id => $quantity) {
      // Get product price
      $product_query = "SELECT * FROM products WHERE product_id = $product_id";
      $product_result = $connection->query($product_query);
      $product = mysqli_fetch_assoc($product_result);
      $product_price = $product['product_price'];

      // Insert each cart item into order_items table
      $insert_order_item = "INSERT INTO order_items (order_id, product_id, quantity, price)
                            VALUES ('$order_id', '$product_id', '$quantity', '$product_price')";
      $connection->query($insert_order_item);
    }

    // Clear cart session after successful checkout
    unset($_SESSION['cart']);
    $_SESSION['cart_num'] = 0;
    
    // Redirect to order confirmation page
    header("Location: order_confirmation.php?order_id=$order_id");
    exit();
  } else {
    die("Error: Could not place the order.");
  }
}
?>
