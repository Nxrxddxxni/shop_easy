<?php ob_start(); ?>
<?php session_start(); ?>
<?php include "includes/db.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles/login.css">
    <link rel="stylesheet" href="styles/checkout.css">
</head>
<body>


<div class="checkout-header">
  <div class="header-content">
    <div class="checkout-header-left-section">
      <a href="shop-easy.php">
      </a>
    </div>
    
    <div class="shop-header">
  <div class="shop-header-left-section">
    <a href="shop-easy.php" class="header-link">
  ShopEasy
    </a>
  </div>

  <div class="shop-header-right-section">
  
  <nav class="navbar">
<ul class="navbar-menu">
  
  <?php
  // $_SESSION['cart'] = [1, 3];
  // echo $_SESSION['cart_num'] = count($_SESSION['cart']);

if(isset($_POST['submit'])){
    $user_pass = $_POST['password'];
    // $user_mail = $_POST['email'];
    $username = $_POST['username'];

    $password_query = "SELECT * FROM users WHERE username = '$username'";
    $password_result = $connection->query($password_query);

    if(mysqli_num_rows($password_result) > 0){
        $row = mysqli_fetch_assoc($password_result);

    if(password_verify($user_pass, $row['password'])){
      if($row['user_role'] === 'user'){
 
        $_SESSION['username'] = $row['username'];
        $_SESSION['user_id'] = $row['user_id'];
        $user_id = $_SESSION['user_id'];
      }else{
        $_SESSION['ad_username'] = $row['username'];
      }
      header("Location: shop-easy.php");
       
    }else{
        header("Location: login.php");
        
    }
}
}

$query = "SELECT * FROM category";
$result = $connection->query($query);

while($row = mysqli_fetch_assoc($result)){
$cat_id = $row['cat_id'];
$cat_name = $row['cat_name'];
?>
<li><a href="categories.php?cat_id=<?php echo $cat_id;?>"><?php echo $cat_name; ?></a></li>  
<?php } 

?>

  </div>
</div>
</header>


    <div class="checkout-header-right-section">
</div>
  </div>
</div>



<main>
    <div class="login-container">
        <h2>Welcome Back!</h2>
        <p>Please log in to your Account</p>

        <form action="login.php" method="POST" class="login-form">
            <div class="form-group">
                <label for="email">Email Or Username</label>
                <input type="text" id="email" name="username" placeholder="Enter your email or username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                <a href="forgot_password.php" class="forgot-password">Forgot password?</a>
            </div>
            <button name='submit' type="submit" class="login-button">Log In</button>
        </form>
       
        <div class="signup-link">
            <p>Don't have an account? <a href="register.php">Sign up here</a></p>
        </div>
    </div>
</main>

</body>
</html>