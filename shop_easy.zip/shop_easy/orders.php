<?php include "includes/db.php"; ?>
<?php include "includes/checkout-header.php"; ?>
<?php ob_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="styles/orders.css">
</head>
<body>

    <?php
    if(isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
    $query = "SELECT * FROM orders WHERE user_id = {$user_id}";
    $result = $connection->query($query);
if(mysqli_num_rows($result) > 0){
  ?>

<div class="order-confirmation">
    <h1>Order Confirmation</h1>
    <h3><p>Thank you for your order!</p></h3>
  
    <?php
    while($row = mysqli_fetch_assoc($result)){

    ?>
    <div class="order-details">
        <p><strong>Order ID:</strong> <?php echo $row['order_id'];; ?></p>
        <p><strong>Transaction ID:</strong> <?php echo $row['transaction_id']; ?></p>
        <p><strong>Total Amount:</strong> &#8358;<?php echo $row['total_amount']; ?></p>
        <p><strong>Shipping Address:</strong> <?php echo $row['shipping_address']; ?></p>
        <p><strong>Order Satus:</strong> <?php echo $row['order_status']; ?></p>
        </div>
        <?php 
    }
    ?>
    <a href="shop-easy.php" class="continue-shopping-button">Continue Shopping</a>
    <?php
    }else{
      echo "<h1>You Don't Have Active Orders Yet</h1>";
    } 
  }else if(isset($_GET['order'])){
    $order_id = $_GET['order'];
    $query = "SELECT * FROM orders WHERE order_id = {$order_id}";
    $result = $connection->query($query);
?>
    <div class="order-confirmation">
    <h1>Order Confirmation</h1>
    <h3><p>Thank you for your order!</p></h3>
  
    <?php
    while($row = mysqli_fetch_assoc($result)){

    ?>
    <div class="order-details">
        <p><strong>Order ID:</strong> <?php echo $row['order_id'];; ?></p>
        <p><strong>Transaction ID:</strong> <?php echo $row['transaction_id']; ?></p>
        <p><strong>Total Amount:</strong> &#8358;<?php echo $row['total_amount']; ?></p>
        <p><strong>Shipping Address:</strong> <?php echo $row['shipping_address']; ?></p>
        <p><strong>Order Satus:</strong> <?php echo $row['order_status']; ?></p>
        </div>
        <?php 
    }
    ?>
    <a href="shop-easy.php" class="continue-shopping-button">Continue Shopping</a>
    <?php
    }else{
      echo "<h1>Login To View Orders</h1>";
    }
    ?>
</div>
</body>
</html>