<?php include "includes/db.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles/checkout.css">
    <link rel="stylesheet" href="styles/login.css">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>
<?php include "includes/checkout-header.php"; ?>

        <div class="checkout-header-right-section"></div>
      </div>
    </div>

    <div class="main">

      <div class="checkout-grid">
        <div class="cart-item-container">
          

<?php
if(isset($_POST['register'])){
    $full_name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm-password']);

    if($password !== $confirm_password){
    echo "<h4 style='color: red;'>Passwords Do Not Match!</h4>";
    }else{

    $pass_hash = password_hash($password, PASSWORD_DEFAULT);
    $query = "INSERT INTO users(user_role, full_name, username, email, password) VALUES('user', '{$full_name}', '{$username}', '{$email}', '{$pass_hash}')";
    $result = $connection->query($query);
    // echo "Hello{$username}, $email yojua";
    echo "<h4 style='color: green;'>Account Created Sucessfully! <a href='login.php'>Log in here</a></h4>";
    // header("Location: login.php");
}
}
?>
    <div class="signup-container">
        <h2>Create Your Account</h2>
        <p>Join us to start shopping!</p>
        <form action="register.php" method="POST" class="signup-form" id="signup-form">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your full name" required>
            </div>
            <div class="form-group">
                <label for="name">User Name</label>
                <input type="text" id="username" name="username" placeholder="Enter your Username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class='password' placeholder="Enter your password" 
                oninput = "checkPassword()"   required>
                <small class="password-hint">Use 6 or more characters</small>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm Password</label>
                <input type="password" oninput='confirmPass()' class='confirm-pass' id="confirm-password" name="confirm-password" placeholder="Confirm your password" required>
                <small class="error-message" id="password-error"></small>
            </div>
            <button type="submit" name='register' class="login-button">Sign Up</button>
        </form>
      
        <div class="login-link">
            <p>Already have an account? <a href="login.php">Log in here</a></p>
        </div>
    </div>
</main>
    <script>

      function checkPassword() {
        
        let pass = document.querySelector('.password').value;
        let conPass = document.querySelector('.confirm-pass').value;
        let hint = document.querySelector('.password-hint');
        let errorMessage = document.querySelector('.error-message');
        
  
      if(pass.length < 6){
        hint.textContent = "Password Must Be Greater than 6 characters"
        hint.style.color = 'red';
      } else {
        hint.textContent = '';
        hint.style.color = 'green'
      }

    }
    function confirmPass(){

      let pass = document.querySelector('.password').value;
        let conPass = document.querySelector('.confirm-pass').value;
        let errorMessage = document.querySelector('.error-message');
       
          if(pass !== conPass){
            errorMessage.style.color = 'red';
            errorMessage.textContent = "Passwords Do Not Match";
          }else{
            errorMessage.textContent = " ";
      }
    }
    

    </script>
</body>