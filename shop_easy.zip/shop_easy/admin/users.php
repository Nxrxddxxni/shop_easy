<?php ob_start(); ?>
<?php include "includes/header.php" ?>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include "includes/navigation.php" ?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Welcome to Admin
                            <small><?php echo isset($_SESSION['ad_username']) ? $_SESSION['ad_username'] : '' ?></small>
                        </h1>
                        <ol class="breadcrumb">
                           
                        </ol>
                        
<table class="table table-bordered table-hover">
<thead>
    <tr>
        <th>Id</th>
        <th>Full Name</th>
        <th>Username</th>
        <th>Role</th>
        <th>Email</th>
        <th>Actions</th>
    </tr>
</thead>
<tbody>
   
<?php    
        $query = "SELECT * FROM users";
        $result = mysqli_query($connection, $query);

        while($row = mysqli_fetch_assoc($result)){
          
            $user_id = $row['user_id'];
            $user_role = $row['user_role'];
            $name = $row['full_name'];
            $username = $row['username'];
            $email = $row['email'];
            
            echo " <tr>"; 
            echo "<td>{$user_id}</td>";
            
            
            // echo "<td><img width = 100 src='../images/{$pro_img} 'alt=' IMG'></td>";
            echo "<td>{$name}</td>";
            echo "<td>{$username}</td>";
            echo "<td>{$user_role}</td>";
            echo "<td>{$email}</td>";
            echo "<td><a href='users.php?user={$user_id}'>Admin</a></td>";
            
        //    
        }     
?>

    
</tbody>
</table>

                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <?php include "includes/footer.php" ?>