
<form action="" class="form-group" method="post">

<?php
if(isset($_GET['update'])){
$cat_id = $_GET['update'];


$query = "SELECT * FROM category WHERE cat_id = $cat_id";
$update_result = mysqli_query($connection, $query);

while($row = mysqli_fetch_assoc($update_result)){
$cat_id = $row['cat_id'];
$cat_name = $row['cat_name'];
?>

<input value="<?php if(isset($cat_name)) {echo $cat_name;} ?>" type="text" name="cat_title" class="form-control" >

<?php }
}

?>

<?php
/////////UPDATE QUERY
if(isset($_POST['update'])){
$cat_title = $_POST['cat_title'];

$query = "UPDATE category SET cat_name = '{$cat_title}' WHERE cat_id = {$cat_id}";
$update_result = mysqli_query($connection, $query);

if(!$update_result){
die("QUERY FAILED" . mysqli_error($connection));
} 

}

?>

<div>
<label for="cat_title">Edit Category</label>
    
</div>
<br>
<div>
    <input type="submit" class="btn btn-primary" name="update" value="Update Category">
</div>
</form>