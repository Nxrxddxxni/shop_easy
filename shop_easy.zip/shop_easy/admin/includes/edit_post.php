<?php
session_start();

if (isset($_GET['p_id'])){
    $pro_id = $_GET['p_id'];

    $query = "SELECT * FROM products WHERE product_id = {$pro_id}";
    $result = mysqli_query($connection, $query);

    while($row = mysqli_fetch_assoc($result)){
            $pro_desc = $row['product_description'];
            $prod_id = $row['product_id'];
            $prod_name = $row['product_name'];
            $pro_cat = $row['product_cat_id'];
            $pro_img = $row['product_image'];
            $pro_price = $row['product_price'];
    }   
    
    if(isset($_POST['update'])){
        
        $pro_name = $_POST['pro_name'];
        $pro_cat = $_POST['cat_name'];
        $pro_price = $_POST['pro_price'];

        $pro_image = $_FILES['pro_img'] ['name'];
        $pro_image_temp = $_FILES['pro_img'] ['tmp_name'];

        $pro_desc = $_POST['pro_desc'];
        move_uploaded_file($pro_image_temp, "../images/$pro_image");


        if(empty($pro_image)){

            $query = "SELECT * FROM products WHERE product_id = $pro_id";
            $result = mysqli_query($connection, $query);
            
            while($row = mysqli_fetch_array($result)){
                $pro_image = $row['product_image'];
            
        }
    }
        $query = "UPDATE products SET  product_cat_id = {$pro_cat}, product_name = '{$pro_name}', product_description = '{$pro_desc}', product_image = '{$pro_image}', product_price = {$pro_price} WHERE product_id = {$pro_id} ";
        
        $result = mysqli_query($connection, $query);
        
        Confirm($result);
        
    }    

}

?>

<div class="form-group">

    <form action="" method="post" enctype="multipart/form-data">
        
        <div class="form-group">
            <label for="title">Product Name</label>
            <input type="text" value="<?php if(isset($_GET['p_id'])) echo $prod_name; ?>" class="form-control" name="pro_name" class="form-control">
        </div>

        <div class="form-group">
        <select name="cat_name" id="cat_name">
        <?php
            $query = "SELECT * FROM category";
            $result = mysqli_query($connection, $query);

            while($row = mysqli_fetch_assoc($result)){
                $cat_id = $row['cat_id'];
                $pro_cat = $row['cat_name'];
            
                echo "<option value='{$cat_id}'>{$pro_cat}</option>";
            }  
        ?>
        </select>
        </div>

        <div>
            <label for="post_author">Product Price</label>
            <input type="text" value="<?php if(isset($_GET['p_id'])) echo $pro_price; ?>" class="form-control" name="pro_price" class="form-control">
        </div>


        <div>
            <img width="100" src="../images/<?php echo $pro_img ?>" alt="">
            <input type="file" class="" name="pro_img" class="form-control">
        </div>

        <div>
            <label for="post_content">Post Description</label>
            <textarea name="pro_desc" value="<?php if(isset($_GET['p_id'])) echo $pro_desc; ?>" id="" cols="30" rows="10" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="create_post"></label>
            <input type="submit" class="btn btn-primary" name="update" value="Update">
        </div>
</form>
</div>