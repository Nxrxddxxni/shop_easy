

<table class="table table-bordered table-hover">
<thead>
    <tr>
        <th>id</th>
        <th>Product Description</th>
        <th>Category</th>
        <th>Image</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
</thead>
<tbody>
   
<?php    
        $query = "SELECT * FROM products";
        $result = mysqli_query($connection, $query);

        while($row = mysqli_fetch_assoc($result)){
          
            $pro_desc = $row['product_description'];
            $prod_id = $row['product_id'];
            $pro_cat = $row['product_cat_id'];
            $pro_img = $row['product_image'];
            $pro_price = $row['product_price'];
            $pro_cat = $row['product_cat_id'];
            
            echo " <tr>"; 
            echo "<td>{$prod_id}</td>";
            echo "<td>{$pro_desc}</td>";
            
            $query ="SELECT * FROM  category";
            $result_selet = mysqli_query($connection, $query);
            
            Confirm($result_selet);

            $query = "SELECT * FROM category WHERE cat_id = {$pro_cat}";
            $update_result = mysqli_query($connection, $query);

            while($row = mysqli_fetch_assoc($update_result)){
            $cat_id = $row['cat_id'];
            $cat_title = $row['cat_name'];
            echo "<td>{$cat_title}</td>";
            }
            
            echo "<td><img width = 100 src='../images/{$pro_img} 'alt=' IMG'></td>";
            // echo "<td>{$post_date}</td>";
            echo "<td><a href='posts.php?source=edit_post&p_id={$prod_id}'</a>Edit</td>";
            echo "<td><a href='posts.php?delete={$prod_id}'</a>Delete</td>";
            
            echo "</tr>";
            
        }

        
               
?>

    
</tbody>
</table>

<?php

if(isset($_GET['delete'])){
    $prod_id = $_GET['delete'];

    $query = "DELETE FROM products WHERE product_id = {$prod_id}";
    $result = mysqli_query($connection, $query);
    header("Location: ./posts.php");
    }           

?>