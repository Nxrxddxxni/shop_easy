<?php
    if(isset($_POST['create_post'])){

        $pro_name = $_POST['title'];
        $pro_cat = $_POST['cat_name'];
        $pro_price = $_POST['pro_price'];

        $pro_image = $_FILES['post_img'] ['name'];
        $pro_image_temp = $_FILES['post_img'] ['tmp_name'];

        $pro_desc = $_POST['pro_desc'];
        move_uploaded_file($pro_image_temp, "../images/$pro_image");

        $query = "INSERT INTO products(product_cat_id, product_name, product_description, product_image, product_price) VALUES ({$pro_cat}, '{$pro_name}', '{$pro_desc}', '{$pro_image}', {$pro_price}) ";
        $result = mysqli_query($connection, $query);

    Confirm($result);


}

?>

<div class="form-group">

    <form action="" method="post" enctype="multipart/form-data">
        
        <div class="form-group">
            <label for="title">Product Name</label>
            <input type="text" class="form-control" name="title" class="form-control">
        </div>
        <div class="form-group">        
            <label for="cat_name">Product category</label>
            <select name="cat_name" id="cat_name">
        <?php
            $query = "SELECT * FROM category";
            $result = mysqli_query($connection, $query);

            while($row = mysqli_fetch_assoc($result)){
                $cat_id = $row['cat_id'];
                $pro_cat = $row['cat_name'];
            
                echo "<option value='{$cat_id}'>{$pro_cat}</option>";
            }  
        ?>
        </select>

        </div>

        <div>
            <label for="post_author">Product Price</label>
            <input type="text" class="form-control" name="pro_price" class="form-control">
        </div>

        <div>
            <label for="post_img">Post Image</label>
            <input type="file" class="" name="post_img" class="form-control">
        </div>

        <div>
            <label for="pro_desc">Product Description</label>
            <textarea name="pro_desc" id="" cols="30" rows="10" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <input type="submit" class="btn btn-primary" name="create_post" value="Publish Post">
        </div>
</form>
</div>