<?php ob_start(); ?>
<?php include "includes/header.php" ?>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include "includes/navigation.php" ?>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Welcome to Admin
                            <small><?php echo isset($_SESSION['username']) ? $_SESSION['username'] : '' ?></small>
                        </h1>
                        <ol class="breadcrumb">
                           
                        </ol>
                        
<table class="table table-bordered table-hover">
<thead>
    <tr>
        <th>id</th>
        <th>user_id</th>
        <th>transaction_id</th>
        <th>Total Amount</th>
        <th>Address</th>
        <th>Date</th>
        <th>Status</th>
        <th>Action</th>
        <th>View Order</th>
    </tr>
</thead>
<tbody>
   
<?php    
        $query = "SELECT * FROM orders";
        $result = mysqli_query($connection, $query);

        while($row = mysqli_fetch_assoc($result)){
          
            $order_id = $row['order_id'];
            $user_id = $row['user_id'];
            $transaction_id = $row['transaction_id'];
            $amount = $row['total_amount'];
            $address = $row['shipping_address'];
            $date = $row['order_date'];
            $status = $row['order_status'];
            
            echo " <tr>"; 
            echo "<td>{$order_id}</td>";
            echo "<td>{$user_id}</td>";
            
            
            // echo "<td><img width = 100 src='../images/{$pro_img} 'alt=' IMG'></td>";
            echo "<td>{$transaction_id}</td>";
            echo "<td>{$amount}</td>";
            echo "<td>{$address}</td>";
            echo "<td>{$date}</td>";
            echo "<td>{$status}</td>";
            echo "<td><a href='view_orders.php?approve={$order_id}'>Approve</a></td>";
            echo "<td><a href='../orders.php?order={$order_id}'>View</a></td>";
            // echo "<td><a href='posts.php?source=edit_post&p_id={$prod_id}'</a>Edit</td>";
            // echo "<td><a href='posts.php?delete={$prod_id}'</a>Delete</td>";
            
            echo "</tr>";
            
        }

        if(isset($_GET['approve'])){
            $approve = $_GET['approve'];
            $query = "UPDATE orders SET order_status = 'Approved' WHERE order_id = {$approve}";
            $result = $connection->query($query);

            header('Location: view_orders.php');
        }
        
               
?>

    
</tbody>
</table>

                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <?php include "includes/footer.php" ?>