<?php

function Confirm($him){
    global $connection;
    if(!$him){
        die("QUERY FAILED" . mysqli_error($connection));
    }
}


//Adding into Categories
function Inserting_cat(){
    
global $connection;
    if(isset($_POST['submit'])){
        $submit = $_POST['cat_title'];
    
        if($submit == "" || empty($submit)) {
            echo "This field should not be empty";
        }else{
    
            $submitQuery = "INSERT INTO category (cat_name) VALUES ('$submit')";
            $submitResult = mysqli_query($connection, $submitQuery);
        
        }
    }
    
?>
    <form action="" class="form-group" method="post">
        
    <div>
    <label for="cat_title">Add Category</label>
        <input type="text" name="cat_title" class="form-control" >
    </div>
    <br>
    <div>
        <input type="submit" class="btn btn-primary" name="submit" value="Add Category">
    </div>
    </form>

    <?php
                           
}

function Reading_Cat(){
    global $connection;
    //Reading Categories
    $query = "SELECT * FROM category";
    $result = mysqli_query($connection, $query);

while($row = mysqli_fetch_assoc($result)) {

$cat_id = $row['cat_id'];
$cat_name = $row['cat_name'];
?>
<tr>
<?php
echo "<td>{$cat_id}</td>";
echo "<td>{$cat_name}</td>";
echo "<td><a href='categories.php?delete={$cat_id}'</a>Delete</td>";
echo "<td><a href='categories.php?update={$cat_id}'</a>Update</td>";
?>
</tr>

<?php 

}
}

//Deleting From categoriesS
function Deleting_Cat(){
    global $connection;

        if(isset($_GET['delete'])){
        $the_id = $_GET['delete'];


        $query = "DELETE FROM category WHERE cat_id = {$the_id}";
        $delete_result = mysqli_query($connection, $query);
        header("Location: categories.php");
        }                  
                                
}

//Updating Categories
function Updating_Cat(){
    global $connection;
if(isset($_GET['update'])){
    $cat_id = $_GET['update'];

    include "includes/edit_categories.php";
}

}


//Updating Posts

?>