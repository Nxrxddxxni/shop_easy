<?php session_start(); ?>
<?php ob_start(); ?>
<?php include"includes/db.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce | | sh*t</title>
    <link rel="stylesheet" href="styles/checkout.css">
    <link rel="stylesheet" href="styles/shop.css">
    <link rel="stylesheet" href="styles/register.css">
</head>
<body>
  <header>
    
  <div class="shop-header">


      <div class="shop-header-left-section">
<?php
if(isset($_SESSION['username'])){
?>

        <a href="shop-easy.php" class="header-link">
        <div class="cart-text"><?php echo isset($_SESSION['username']) ? $_SESSION['username'] : ''; ?></div>
        </a>
        
        <a class='logout-link header-link' href="logout.php">
          <span class='logout-text'>Logout</span>
      </a>

        <?php
}else{
?>
  <a href="login.php" class="header-link">
        <div class="cart-text"><?php echo isset($_SESSION['ad_username']) ? $_SESSION['ad_username'] : 'Login'; ?></div>
        </a>
<?php
}
?>
      </div>


      <form action="search.php" method=POST>
      <div class="shop-header-middle-section">
        <input class="search-bar" name='value' type="text" placeholder="Search">

        <button class="search-button" type='submit' name='search'>
          <img class="search-icon" src="icons/search-icon.png">
        </button> 
      </div>
    </form>

      <div class="shop-header-right-section">
        <a class="orders-link header-link" href="orders.php">
          <span class="orders-text">Orders</span>
        </a>

        <a class="cart-link header-link" href="checkout.php">
          <img class="cart-icon" src="icons/cart-icon.png">
          <div class="cart-quantity js-cart-quantity"><?php echo isset($_SESSION['cart_num']) ? $_SESSION['cart_num']: 0; ?></div>
        </a>

      </div>
    </div>
  </header>
