<?php
ob_start();
session_start();
include "includes/db.php"; // Ensure database connection

// Initialize cart for guests
if (!isset($_SESSION['user_id'])) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
        $_SESSION['cart_num'] = count($_SESSION['cart']);
    }
} else {
    $_SESSION['cart'] = NULL;
    $_SESSION['cart_num'] = NULL;
}

// Handle adding products to cart (for logged-in users)
if (isset($_GET['pro_id']) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $pro_id = intval($_GET['pro_id']);

    // Check if product already in cart
    $query = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt = $connection->prepare($query);
    $stmt->bind_param("ii", $user_id, $pro_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Product exists, update quantity
        $update_query = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?";
        $stmt = $connection->prepare($update_query);
        $stmt->bind_param("ii", $user_id, $pro_id);
        $stmt->execute();
    } else {
        // Insert new product into cart
        $insert_query = "INSERT INTO cart (product_id, user_id, quantity) VALUES (?, ?, 1)";
        $stmt = $connection->prepare($insert_query);
        $stmt->bind_param("ii", $pro_id, $user_id);
        $stmt->execute();
    }

    // Update cart count
    $count_query = "SELECT COUNT(*) AS cart_count FROM cart WHERE user_id = ?";
    $stmt = $connection->prepare($count_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $count_result = $stmt->get_result();
    $_SESSION['cart_num'] = $count_result->fetch_assoc()['cart_count'];
}

// Handle guest cart logic
if (isset($_GET['pro_id_g'])) {
    $prod_id = intval($_GET['pro_id_g']);
    $_SESSION['cart'][$prod_id] = ($_SESSION['cart'][$prod_id] ?? 0) + 1;
    $_SESSION['cart_num'] = array_sum($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles/checkout.css">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

    <div class="checkout-header">
      <div class="header-content">
        <div class="checkout-header-left-section">
          <a href="checkout-easy.php"></a>
        </div>
        
        <div class="checkout-header">
          <div class="checkout-header-left-section">
            <a href="shop-easy.php" class="header-link">ShopEasy</a>
          </div>

          <div class="checkout-header-right-section">
            <nav class="navbar">
              <ul class="navbar-menu">
                <?php
                $query = "SELECT * FROM category";
                $result = $connection->query($query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<li><a href="categories.php?cat_id=' . $row['cat_id'] . '">' . $row['cat_name'] . '</a></li>';
                }
                ?>
                <a href="orders.php"><li>Orders</li></a>
              </ul>
            </nav>
          </div>
        </div>

        <div class="checkout-header-right-section">
          
        </div>
      </div>
    </div>
