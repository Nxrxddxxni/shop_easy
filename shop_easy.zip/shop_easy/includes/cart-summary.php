
                
              </div>
<?php
if (isset($_GET['delete'])) {
  $delete = $_GET['delete'];

  if (isset($_SESSION['user_id'])) {
      $query = "DELETE FROM cart WHERE cart_id = $delete";
      $result = mysqli_query($connection, $query);
  } else {
      unset($_SESSION['cart'][$delete]); // Remove from session-based cart
      $_SESSION['cart_num'] = array_sum($_SESSION['cart']); // Update cart count
  }
  
  header("Location: checkout.php");
  exit();
}

?>


        <div class="payment-summary">
          <div class="payment-summary-title">
            Cart Summary
          </div>

          <div class="payment-summary-row">
            <div>Items ( <?php echo $_SESSION['cart_num']?>):</div>
            <div class="payment-summary-money">&#8358;<?php echo number_format($items_cost, 2); ?></div>
          </div>

          <div class="payment-summary-row">
            <div>Shipping Fee:</div>
            <div class="payment-summary-money">&#8358;<?php echo number_format($items_cost * 0.01, 2); ?></div>
          </div>

          <div class="payment-summary-row total-row">
            <div>Order total:</div>
            <div class="payment-summary-money">&#8358;<?php echo $_SESSION['order_total'] = number_format($items_cost + ($items_cost * 0.01), 2); ?></div>
          </div>

          <a href="checkout.php?checkout"><button class="place-order-button" name='checkout'>
            Proceed to Checkout
          </button>
</a> 
        </div>
      </div>
     
    </div>
  </body>
</html>

<?php
if(isset($_GET['checkout'])){
  if(isset($_SESSION['user_id'])){
    $query = "SELECT * FROM cart WHERE user_id = {$_SESSION['user_id']}";
        $result = mysqli_query($connection, $query);
    if(mysqli_num_rows($result) > 0){
    header("Location: checkout_process.php");
    }
  }else{
    header("Location: login.php");
  }
}

?>