<?php

$servername = 'localhost';
$username = 'root';
$password = '';
$db_name = 'shop_easy';

$connection = new mysqli($servername, $username, $password, $db_name);

?>