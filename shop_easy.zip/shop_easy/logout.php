<?php
session_start();
ob_start();

header("Location: login.php");
$_SESSION['username'] = NULL;
$_SESSION['user_id'] = NULL;

session_destroy();
?>