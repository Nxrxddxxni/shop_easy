<?php include "includes/header.php" ?>
    <main>
      
    <div class="main">
      

      <div class="products-grid">
      
      <?php
      if(isset($_GET['cat_id'])){
        $cat_id = $_GET['cat_id'];
      
      
      $query = "SELECT * FROM products WHERE product_cat_id = $cat_id";
      $result = $connection->query($query);

      while($row = mysqli_fetch_assoc($result)){
        $pro_desc = $row['product_description'];
        $pro_id = $row['product_id'];
        $pro_img = $row['product_image'];
        $pro_price = $row['product_price'];
        $pro_cat = $row['product_cat_id'];
      
      ?>

       <div class="product-container">
          <div class="product-image-container">
            <img class="product-image" src='images/<?php echo $pro_img?>' loading='lazy'>
          </div>
          <div class="product-name limit-text-to-2-lines"><?php echo $pro_desc; ?></div>
  
          <div class="product-price">&#8358;<?php echo number_format($pro_price, 2); ?></div>
          <div class="product-quantity-container">
            <select>
              <option selected value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
          </div>
          <div class="product-spacer"></div>
          <div class="added-to-cart">
            <img src="images/icons/checkmark.png"> Added
          </div>
          
            <?php if(isset($_SESSION['username'])){ ?>
            <a href="checkout.php?pro_id=<?php echo $pro_id; ?>"><button class="add-to-cart-button button-primary">
           Add to Cart 
          </button></a>
      <?php }else {
        ?>
             <a href="checkout.php?pro_id_g=<?php echo $pro_id; ?>"><button class="add-to-cart-button button-primary">
           Add to Cart 
          </button></a>
    <?php      }
        ?> 
        </div>

      <?php } 
      }?>


</div>
    </main>

</body>
</html>